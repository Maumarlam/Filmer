package com.example.filmer2;

import android.graphics.Movie;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import Utilities.NetworkUtils;
import butterknife.BindView;
import butterknife.ButterKnife;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Variables
    String popularMovies;
    String topRatedMovies;
    ArrayList<NetworkUtils.Movie> myPopularList;
    ArrayList<NetworkUtils.Movie> myTopTopRatedList;

    @BindView(R.id.indeterminateBar)
    ProgressBar myProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        myProgressBar.setVisibility(View.INVISIBLE); //Hide Progressbar by Default

        new FetchMovies().execute(); //Run the background tasks with async
    }


    //AsyncTask
    public class FetchMovies extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {         //Shows the progress bar
            super.onPreExecute();
            myProgressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            //Too lazy to add protection or encryption of any kind for the api key sorry professor hehe
            String popularMoviesURL = "http://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=" + "dc65648ae033b0600f07446a6b592bee";
            String topRatedMoviesURL = "http://api.themoviedb.org/3/discover/movie?sort_by=vote_average.desc&api_key=" + "dc65648ae033b0600f07446a6b592bee";


            myPopularList = new ArrayList<>();
            myTopTopRatedList = new ArrayList<>();

            try {
                if (NetworkUtils.networkStatus(MainActivity.this)) {
                    myPopularList = NetworkUtils.fetchData(popularMoviesURL); //Get popular movies
                    myTopTopRatedList = NetworkUtils.fetchData(topRatedMoviesURL); //Get top rated movies
                } else {
                    Toast.makeText(MainActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void s) {         //Makes the progress bar hide again
            super.onPostExecute(s);
            myProgressBar.setVisibility(View.INVISIBLE);
        }
    }
}
